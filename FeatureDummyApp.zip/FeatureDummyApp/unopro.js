{
  "iOS": {
    "DevelopmentTeam": "Your-Dev-ID"
  }
}
