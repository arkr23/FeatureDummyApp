
		var Observable = require("FuseJS/Observable");


		//Router Functions
			function gotoFirstPage(args) {

//	Unterschiede zwischen goto und push sind in der Animation,
//	bei Push wird es wie in der iOS App zum linken Rand hin weg
//	geschoben. Bei Goto fällt es in sich zusammen und wischt dann.
//	Push funktionert nur in --> richtig. Wenn es <-- geht ist
//	die Animation falsch.

				//router.goto('first',{});
				router.push('first',{});
			}

			function gotoGeoLocation(args) {

				router.push('toGeoLocation',{});
			}

			function gotoKamera(args) {

				router.push('toKamera',{});
			}

			function gotoPhone(args) {

				router.push('toPhone',{});
			}

			function gotoWebView(args) {

				router.push('toWebView',{});
			}

			function gotoMaps(args) {

				router.push('toMaps',{});
			}

			function gotoLocalNachrichten(args) {

				router.push('toLocalNachrichten',{});
			}

			function gotoVibration(args) {

				router.push('toVibration',{});
			}

			function gotoPerformanceTest(args) {

				router.push('toPerformanceTest',{});
			}

			/*function gotoFunction(args) {

				router.push('toFunction',{});
			}*/

		module.exports = {
			gotoFirstPage: gotoFirstPage,
			gotoGeoLocation: gotoGeoLocation,
			gotoKamera: gotoKamera,
			gotoPhone: gotoPhone,
			gotoWebView: gotoWebView,
			gotoMaps: gotoMaps,
			gotoLocalNachrichten: gotoLocalNachrichten,
			gotoVibration: gotoVibration,
			gotoPerformanceTest: gotoPerformanceTest,
			//gotoFunction: gotoFunction,

		};
