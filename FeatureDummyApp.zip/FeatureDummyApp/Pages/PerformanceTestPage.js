/*
JavaScript Code zur PerformanceTestPage.ux Datei.
Hier werden JSON Daten von geladen
und an das UI(PerformanceTestPage.ux) übergeben.
*/
var Observable = require("FuseJS/Observable");
var pictures = Observable();
var errorMessage = Observable();
var loadingTime = 3.1415; 
//function stopwatch(){
//var start = new Date().getTime();
var pageName ="Performance Test";

// EXECUTION PART
var needTime = fetch("https://andreas-rickert.com/ba/generated.json")
		.then(function(result) {
			if (result.status !== 200) {
				debug_log("Something went wrong, status code: " + result.status);
				errorMessage.value = "Oh noes! :(";
				return;
			}

		//Fehler werfen
		return result.json();
		}).then(function(data, time) {
			debug_log("Success, JSON Daten werden geladen !");

				var itemsInJSON = 100;

				for (var i = 0; i <= itemsInJSON; i++) {
					var item = data[i];
					//console.log(item)
					pictures.add(item);

						// if (i == itemsInJSON) {
						// 	var end = new Date().getTime();
						// 	var time = end - start;
						// 	console.log("Ende:" + end);
						// 	console.log('Daten wurden in ' + time + ' ms geladen');
						// 	console.log('_______________________________________');
						// }
				}

				return time;
			}).catch(function(error) {
				debug_log("Fetch error " + error);
					errorMessage.value = "Oh noes! :(";
			});
function gotoFirstPage(args) {
	router.goto('first',{});
}

function gotoSecondPage(args) {
	router.goto('second', {});
}

module.exports = {
	gotoFirstPage: gotoFirstPage,
	gotoSecondPage: gotoSecondPage,
	pageName: pageName,
	pictures: pictures,
	errorMessage: errorMessage,
	loadingTime: loadingTime,
	needTime: needTime
};
